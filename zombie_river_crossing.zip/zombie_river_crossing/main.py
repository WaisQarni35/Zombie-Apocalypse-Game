"""
main.py
Entry point. Run with:  python main.py
"""

import pygame
from settings import WIDTH, HEIGHT, FPS
from game_manager import GameManager


def main():
    pygame.init()
    try:
        pygame.mixer.init()
    except Exception:
        pass  # No audio device available -- game still runs, just silent

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Zombie Apocalypse: River Crossing")

    gm = GameManager(screen)
    clock = pygame.time.Clock()

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                gm.handle_event(event)

        gm.update(dt)
        gm.draw()
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
