"""
game_manager.py
GameManager: the "engine" class that owns the game loop logic --
state machine (menu / playing / paused / win / lose), event handling,
scoring, the zombie countdown timer, and all drawing.
"""

import pygame
from settings import (
    WIDTH, HEIGHT, WHITE, GREEN, DARK_GREEN, BLUE_RIVER, RED, YELLOW,
    GRAY, TEXT,
)
from entities import create_entities, bank_is_dangerous
from raft import Raft
from level import get_levels
from utils import load_image, load_sound, play_sound


class GameManager:
    def __init__(self, screen):
        self.screen = screen

        self.font_big = pygame.font.SysFont("arial", 46, bold=True)
        self.font_med = pygame.font.SysFont("arial", 26, bold=True)
        self.font_small = pygame.font.SysFont("arial", 19)

        self.lang = "en"
        self.levels = get_levels()
        self.level_index = 0
        self.score = 0
        self.trips = 0
        self.lose_reason = "lose_time"
        self.state = "MENU"

        # --- IMAGE/SOUND INSERTION POINTS (shared assets) ---
        self.snd_click = load_sound("assets/sounds/click.wav")     # <-- SOUND: click.wav
        self.snd_launch = load_sound("assets/sounds/launch.wav")   # <-- SOUND: launch.wav
        self.snd_win = load_sound("assets/sounds/win.wav")         # <-- SOUND: win.wav
        self.snd_lose = load_sound("assets/sounds/lose.wav")       # <-- SOUND: lose.wav

        self.menu_bg = load_image("assets/images/menu_bg.png", (WIDTH, HEIGHT), (20, 20, 20))  # <-- IMAGE: menu_bg.png
        self.zombie_img = load_image("assets/images/zombie.png", (70, 90), (90, 20, 20))        # <-- IMAGE: zombie.png

        self.level = None
        self.entities = None
        self.raft = None
        self.time_left = 0.0
        self.bg = None

        self.load_level(0, reset_score=True)
        self.state = "MENU"
        self._play_music("assets/sounds/menu_music.mp3")  # <-- SOUND: menu_music.mp3

    def _play_music(self, path):
        """Background music switcher. Safe no-op if the file is missing
        or no audio device is available -- never crashes the game."""
        if getattr(self, "_current_music", None) == path:
            return
        self._current_music = path
        try:
            import os
            if os.path.exists(path):
                pygame.mixer.music.load(path)
                pygame.mixer.music.play(loops=-1)
            else:
                pygame.mixer.music.stop()
        except Exception:
            pass

    # ---------------------------------------------------------------- text
    def t(self, key):
        return TEXT[self.lang][key]

    # ---------------------------------------------------------- level setup
    def load_level(self, index, reset_score=False):
        if reset_score:
            self.score = 0
        self.level_index = index
        self.level = self.levels[index]
        self.entities = create_entities(self.level.entity_keys)
        self.time_left = float(self.level.time_limit)
        self.trips = 0
        self.bg = load_image(self.level.background_path, (WIDTH, HEIGHT), (25, 60, 25))
        self.raft = Raft(
            capacity=self.level.raft_capacity,
            start_x=self.level.river_left - 70,
            end_x=self.level.river_right - 70,
            y=HEIGHT - 140,
        )
        self.arrange_bank_entities()
        self.state = "PLAYING"
        self._play_music("assets/sounds/game_music.mp3")  # <-- SOUND: game_music.mp3

    def restart_level(self):
        self.load_level(self.level_index)

    def go_to_menu(self):
        self.state = "MENU"
        self._play_music("assets/sounds/menu_music.mp3")

    def next_level(self):
        if self.level_index + 1 >= len(self.levels):
            self.state = "ALL_WIN"
        else:
            self.load_level(self.level_index + 1)

    def arrange_bank_entities(self):
        start_i, end_i = 0, 0
        for e in self.entities.values():
            if e.side == "start":
                e.set_pos((110, 110 + start_i * 80))
                start_i += 1
            elif e.side == "end":
                e.set_pos((WIDTH - 110, 110 + end_i * 80))
                end_i += 1

    # ----------------------------------------------------------------- input
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_l:
                self.lang = "my" if self.lang == "en" else "en"

            if self.state == "MENU":
                if event.key == pygame.K_RETURN:
                    self.load_level(0, reset_score=True)
                elif event.key == pygame.K_i:
                    self.state = "INSTRUCTIONS"
                elif event.key == pygame.K_ESCAPE:
                    pygame.event.post(pygame.event.Event(pygame.QUIT))

            elif self.state == "INSTRUCTIONS":
                if event.key == pygame.K_ESCAPE:
                    self.go_to_menu()

            elif self.state == "PLAYING":
                self._handle_playing_keys(event.key)

            elif self.state == "PAUSED":
                if event.key == pygame.K_p:
                    self.state = "PLAYING"
                elif event.key == pygame.K_ESCAPE:
                    self.go_to_menu()

            elif self.state in ("LEVEL_WIN", "GAME_LOSE", "ALL_WIN"):
                if event.key == pygame.K_r:
                    self.restart_level()
                elif event.key == pygame.K_RETURN and self.state == "LEVEL_WIN":
                    self.next_level()
                elif event.key == pygame.K_ESCAPE:
                    self.go_to_menu()

        if event.type == pygame.MOUSEBUTTONDOWN and self.state == "PLAYING":
            self._handle_click(event.pos)

    def _handle_playing_keys(self, key):
        if key == pygame.K_SPACE:
            if self.raft.launch():
                self.trips += 1
                play_sound(self.snd_launch)
        elif key == pygame.K_p:
            self.state = "PAUSED"
        elif key == pygame.K_r:
            self.restart_level()

    def _handle_click(self, pos):
        """
        Mouse-only interaction:
        1. Click an entity standing on a bank  -> select / deselect it (yellow outline).
        2. Click the raft (with an entity selected, raft docked on that same side)
           -> boards the selected entity. This takes priority even if the click
           also visually overlaps a passenger already aboard, so boarding a
           full raft is never blocked by sprite overlap.
        3. Click an entity that is currently ON the raft (with nothing selected)
           -> it departs immediately onto whichever bank the raft is docked at.
        """
        selected = next((e for e in self.entities.values() if e.selected), None)

        # Priority 1: boarding intent always wins if something is selected
        # and the raft (docked at that entity's bank) was clicked.
        if (selected is not None and selected.side == self.raft.location
                and self.raft.rect.collidepoint(pos)):
            if self.raft.board(selected):
                selected.selected = False
                play_sound(self.snd_click)
            self.arrange_bank_entities()
            return

        # Priority 2: click a passenger aboard the raft -> depart.
        for e in self.entities.values():
            if e.side == "raft" and e.rect.collidepoint(pos):
                if self.raft.location in ("start", "end"):
                    if self.raft.unboard(e):
                        play_sound(self.snd_click)
                self.arrange_bank_entities()
                return

        # Priority 3: click an entity on a bank -> toggle selection.
        for e in self.entities.values():
            if e.side in ("start", "end") and e.rect.collidepoint(pos):
                if e.selected:
                    e.selected = False
                else:
                    for other in self.entities.values():
                        other.selected = False
                    e.selected = True
                play_sound(self.snd_click)
                return

    # ---------------------------------------------------------------- update
    def update(self, dt):
        if self.state != "PLAYING":
            return

        self.time_left -= dt
        self.raft.update(dt)
        self._position_raft_passengers()
        self.arrange_bank_entities()

        if self._check_danger():
            self.state = "GAME_LOSE"
            self.lose_reason = "lose_danger"
            play_sound(self.snd_lose)
            return

        if self.time_left <= 0:
            self.time_left = 0
            self.state = "GAME_LOSE"
            self.lose_reason = "lose_time"
            play_sound(self.snd_lose)
            return

        if all(e.side == "end" for e in self.entities.values()):
            self._finish_level()

    def _position_raft_passengers(self):
        n = len(self.raft.passengers)
        if n == 0:
            return
        slot_w = self.raft.rect.width / (n + 1)
        for i, e in enumerate(self.raft.passengers):
            x = self.raft.rect.left + slot_w * (i + 1)
            e.set_pos((x, self.raft.rect.centery - 25))

    def _check_danger(self):
        """
        Determine if any 'location' currently has an unsupervised volatile
        entity. A location is: the start bank, the end bank, or the raft
        itself while mid-crossing. While the raft is DOCKED at a bank, its
        passengers count as still being at that bank (they haven't
        physically left yet) -- this lets the player board two entities
        one click at a time without an unfair false-loss in between clicks.
        While the raft is actually moving, its passengers are checked as
        their own isolated group (e.g. Soldier + Dog alone on a moving
        raft with no Doctor is still dangerous).
        """
        start_bank = [e for e in self.entities.values() if e.side == "start"]
        end_bank = [e for e in self.entities.values() if e.side == "end"]
        raft_group = list(self.raft.passengers)

        if self.raft.location == "start":
            start_bank += raft_group
            raft_group = []
        elif self.raft.location == "end":
            end_bank += raft_group
            raft_group = []

        return (
            bank_is_dangerous(start_bank)
            or bank_is_dangerous(end_bank)
            or bank_is_dangerous(raft_group)
        )

    def _finish_level(self):
        time_bonus = int(self.time_left) * 10
        trip_penalty = self.trips * 5
        level_score = max(0, time_bonus - trip_penalty + 100)
        self.score += level_score
        self.state = "LEVEL_WIN"
        play_sound(self.snd_win)

    # ----------------------------------------------------------------- draw
    def draw(self):
        if self.state == "MENU":
            self._draw_menu()
        elif self.state == "INSTRUCTIONS":
            self._draw_instructions()
        else:
            self._draw_game()
            if self.state == "PAUSED":
                self._draw_overlay(self.t("paused"))
            elif self.state == "LEVEL_WIN":
                self._draw_overlay(
                    self.t("win_level"),
                    extra=f"{self.t('score')}: {self.score}   |   ENTER: Next Level",
                )
            elif self.state == "GAME_LOSE":
                self._draw_overlay(self.t(self.lose_reason), extra=self.t("restart"))
            elif self.state == "ALL_WIN":
                self._draw_overlay(self.t("win_all"), extra=f"{self.t('score')}: {self.score}")

    def _draw_menu(self):
        self.screen.blit(self.menu_bg, (0, 0))

        # IMAGE: Feel free to insert a zombie / poster illustration
        # anywhere in the band between y=150 and y=300 here in _draw_menu().

        title = self.font_big.render(self.t("title"), True, RED)
        self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 120))

        opts = [
            f"ENTER  -  {self.t('start')}",
            f"I  -  {self.t('instructions')}",
            f"ESC  -  {self.t('exit')}",
        ]
        for i, opt in enumerate(opts):
            s = self.font_med.render(opt, True, WHITE)
            self.screen.blit(s, (WIDTH // 2 - s.get_width() // 2, 320 + i * 50))

        hint = self.font_small.render(self.t("lang_hint"), True, YELLOW)
        self.screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, 560))

    def _draw_instructions(self):
        self.screen.fill((15, 15, 15))
        title = self.font_med.render(self.t("instructions"), True, YELLOW)
        self.screen.blit(title, (60, 40))

        lines = TEXT[self.lang]["controls"]
        for i, line in enumerate(lines):
            s = self.font_small.render(line, True, WHITE)
            self.screen.blit(s, (60, 100 + i * 27))

        back = self.font_small.render(self.t("back"), True, YELLOW)
        self.screen.blit(back, (60, HEIGHT - 50))

    def _draw_game(self):
        # Your background image (level1_bg.png / level2_bg.png) IS the
        # river + banks. If you haven't inserted one yet, load_image()
        # falls back to a plain dark-green placeholder so it still runs.
        self.screen.blit(self.bg, (0, 0))

        self.raft.draw(self.screen)
        for e in self.entities.values():
            e.draw(self.screen, self.font_small)

        # ---- HUD: zombie countdown bar ----
        frac = max(0.0, self.time_left / self.level.time_limit)
        bar_w = 300
        pygame.draw.rect(self.screen, GRAY, (20, 20, bar_w, 22))
        color = GREEN if frac > 0.4 else (RED if frac < 0.2 else YELLOW)
        pygame.draw.rect(self.screen, color, (20, 20, int(bar_w * frac), 22))
        label = self.font_small.render(f"{self.t('time_left')}: {int(self.time_left)}s", True, WHITE)
        self.screen.blit(label, (20, 46))

        # Zombie horde creeps in from the wilderness toward the CAMP (left bank)
        # as time runs out -- the camp you started from is what gets overrun,
        # not the safe far bank you're escaping to.
        zx = -80 + (1 - frac) * (self.level.river_left + 60)
        self.screen.blit(self.zombie_img, (zx, 10))

        info = self.font_small.render(
            f"{self.level.name}   |   {self.t('trips')}: {self.trips}   |   {self.t('score')}: {self.score}",
            True, WHITE,
        )
        self.screen.blit(info, (WIDTH - info.get_width() - 20, 20))

        hint = self.font_small.render(
            "Click entity to select -> click raft to board   |   SPACE launch   "
            "|   click entity on raft to depart   |   P pause   R restart   L language",
            True, WHITE,
        )
        self.screen.blit(hint, (20, HEIGHT - 30))

    def _draw_overlay(self, text, extra=None):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))

        s = self.font_big.render(text, True, YELLOW)
        self.screen.blit(s, (WIDTH // 2 - s.get_width() // 2, HEIGHT // 2 - 60))

        if extra:
            s2 = self.font_med.render(extra, True, WHITE)
            self.screen.blit(s2, (WIDTH // 2 - s2.get_width() // 2, HEIGHT // 2 + 10))

        s3 = self.font_small.render(self.t("menu_hint"), True, WHITE)
        self.screen.blit(s3, (WIDTH // 2 - s3.get_width() // 2, HEIGHT // 2 + 60))
