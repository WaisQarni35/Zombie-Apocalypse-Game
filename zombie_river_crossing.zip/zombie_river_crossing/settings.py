"""
settings.py
Global constants: screen size, colors, and the bilingual (EN / Bahasa Melayu)
text dictionary used by the UI (bonus: bilingual interface).
"""

WIDTH, HEIGHT = 1100, 650
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (60, 140, 60)
DARK_GREEN = (30, 90, 30)
BLUE_RIVER = (40, 90, 150)
RED = (200, 40, 40)
YELLOW = (240, 200, 40)
GRAY = (60, 60, 60)
DARK_RED = (120, 0, 0)

TEXT = {
    "en": {
        "title": "ZOMBIE APOCALYPSE: RIVER CROSSING",
        "start": "Start Game",
        "instructions": "Instructions",
        "exit": "Exit",
        "back": "Back (ESC)",
        "paused": "PAUSED - Press P to resume",
        "win_level": "LEVEL COMPLETE!",
        "win_all": "YOU SURVIVED! ALL LEVELS COMPLETE",
        "lose_time": "THE HORDE OVERRAN THE CAMP! Time's up.",
        "lose_danger": "DISASTER! Unsupervised entities were caught by zombies!",
        "score": "Score",
        "time_left": "Zombie Horde ETA",
        "trips": "Trips",
        "restart": "Press R to Restart",
        "menu_hint": "Press ESC to return to Menu",
        "lang_hint": "Press L to switch to Bahasa Melayu",
        "controls": [
            "GOAL: Move the Doctor, Soldier, Child and Dog from the camp",
            "(LEFT bank) across the river to safety (RIGHT bank) before the",
            "zombie horde overruns the camp behind you.",
            "",
            "RULES:",
            "- The Raft can only be rowed by the Doctor or the Soldier.",
            "- The Dog must NEVER be left with the Soldier or the Child",
            "  unless the Doctor is also present (zombies will attack!).",
            "- The Raft carries a maximum of 2 entities at a time.",
            "",
            "CONTROLS (Mouse only):",
            "1. Click an entity on the bank to select it (yellow outline).",
            "2. Click the raft to board the selected entity.",
            "3. Press SPACE to launch the raft across the river.",
            "4. Click an entity standing on the raft to make it depart",
            "   onto the bank the raft is currently docked at.",
            "",
            "P - Pause / Resume      R - Restart Level",
            "L - Switch Language     ESC - Back to Menu",
        ],
    },
    "my": {
        "title": "WABAK ZOMBIE: MERENTASI SUNGAI",
        "start": "Mula Permainan",
        "instructions": "Arahan",
        "exit": "Keluar",
        "back": "Kembali (ESC)",
        "paused": "DIBERHENTIKAN - Tekan P untuk sambung",
        "win_level": "TAHAP SELESAI!",
        "win_all": "ANDA TERSELAMAT! SEMUA TAHAP SELESAI",
        "lose_time": "PERKHEMAHAN DITAWAN ZOMBIE! Masa tamat.",
        "lose_danger": "BENCANA! Entiti tanpa pengawasan diserang zombie!",
        "score": "Markah",
        "time_left": "Anggaran Ketibaan Zombie",
        "trips": "Perjalanan",
        "restart": "Tekan R untuk Mula Semula",
        "menu_hint": "Tekan ESC untuk ke Menu",
        "lang_hint": "Press L to switch to English",
        "controls": [
            "MATLAMAT: Bawa Doktor, Askar, Kanak-kanak dan Anjing dari",
            "perkhemahan (tebing KIRI) merentasi sungai ke tebing KANAN",
            "yang selamat sebelum zombie menawan perkhemahan di belakang anda.",
            "",
            "PERATURAN:",
            "- Rakit hanya boleh dikayuh oleh Doktor atau Askar.",
            "- Anjing TIDAK BOLEH ditinggalkan dengan Askar atau Kanak-kanak",
            "  melainkan Doktor turut hadir (zombie akan menyerang!).",
            "- Rakit membawa maksimum 2 entiti setiap kali.",
            "",
            "KAWALAN (Tetikus sahaja):",
            "1. Klik entiti di tebing untuk memilihnya (garis kuning).",
            "2. Klik rakit untuk menaikkan entiti yang dipilih.",
            "3. Tekan SPACE untuk melancarkan rakit merentasi sungai.",
            "4. Klik entiti yang berada di atas rakit untuk turun",
            "   ke tebing tempat rakit sedang berlabuh.",
            "",
            "P - Jeda / Sambung      R - Mula Semula Tahap",
            "L - Tukar Bahasa        ESC - Kembali ke Menu",
        ],
    },
}
