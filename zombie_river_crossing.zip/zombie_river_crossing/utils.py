"""
utils.py
Helper functions for loading images/sounds safely.
If an asset file is missing, a colored placeholder is used instead so the
game ALWAYS runs without crashing (a project requirement).
"""

import os
import pygame


def load_image(path, size, fallback_color):
    """Load an image from `path` and scale to `size`.
    If the file does not exist (or fails to load), returns a colored
    placeholder rectangle of the same size instead -- and prints a warning
    so it's obvious in the console why your art isn't showing up."""
    surf = None
    if os.path.exists(path):
        try:
            surf = pygame.image.load(path).convert_alpha()
            surf = pygame.transform.smoothscale(surf, size)
        except Exception as ex:
            print(f"[asset warning] Found '{path}' but could not load it ({ex}). Using placeholder.")
            surf = None
    else:
        print(f"[asset warning] Image not found at '{path}' (looked relative to "
              f"the current working directory: '{os.getcwd()}'). Using placeholder.")
    if surf is None:
        surf = pygame.Surface(size, pygame.SRCALPHA)
        surf.fill(fallback_color)
        pygame.draw.rect(surf, (0, 0, 0), surf.get_rect(), 2)
    return surf


def load_sound(path):
    """Load a sound effect. Returns None if missing/unavailable."""
    if os.path.exists(path):
        try:
            return pygame.mixer.Sound(path)
        except Exception:
            return None
    return None


def play_sound(sound):
    if sound:
        try:
            sound.play()
        except Exception:
            pass
