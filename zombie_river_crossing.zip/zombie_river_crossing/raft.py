"""
raft.py
The Raft class: handles capacity limits, who can pilot it, boarding /
unboarding, and smooth (physics-style, frame-rate independent) movement
across the river.
"""

import pygame
from utils import load_image


class Raft:
    def __init__(self, capacity, start_x, end_x, y, speed=180):
        self.capacity = capacity
        self.start_x = start_x
        self.end_x = end_x
        self.y = y
        self.x = start_x
        self.speed = speed  # pixels per second
        self.passengers = []
        self.location = "start"  # "start", "end", "moving_to_end", "moving_to_start"

        raft_width = max(140, 70 * capacity + 20)
        self.image = load_image(
            "assets/images/raft.png",   # <-- IMAGE: Raft sprite
            (raft_width, 70), (120, 80, 40),
        )
        self.rect = self.image.get_rect(midleft=(self.x, self.y))

    def has_rower(self):
        return any(e.can_row for e in self.passengers)

    def is_full(self):
        return len(self.passengers) >= self.capacity

    def board(self, entity):
        if self.location not in ("start", "end"):
            return False
        if entity.side != self.location:
            return False
        if self.is_full():
            return False
        self.passengers.append(entity)
        entity.side = "raft"
        return True

    def unboard(self, entity):
        if entity not in self.passengers:
            return False
        if self.location not in ("start", "end"):
            return False
        self.passengers.remove(entity)
        entity.side = self.location
        return True

    def launch(self):
        """Send the raft across, but only if a valid rower is aboard."""
        if self.location == "start" and self.has_rower():
            self.location = "moving_to_end"
            return True
        if self.location == "end" and self.has_rower():
            self.location = "moving_to_start"
            return True
        return False

    def update(self, dt):
        """Smooth, frame-rate-independent movement of the raft."""
        if self.location == "moving_to_end":
            self.x += self.speed * dt
            if self.x >= self.end_x:
                self.x = self.end_x
                self.location = "end"
        elif self.location == "moving_to_start":
            self.x -= self.speed * dt
            if self.x <= self.start_x:
                self.x = self.start_x
                self.location = "start"
        self.rect.midleft = (self.x, self.y)

    def reset(self):
        self.passengers = []
        self.x = self.start_x
        self.location = "start"
        self.rect.midleft = (self.x, self.y)

    def draw(self, surface):
        surface.blit(self.image, self.rect)
