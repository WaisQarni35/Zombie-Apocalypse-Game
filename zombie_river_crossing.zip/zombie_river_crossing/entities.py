"""
entities.py
OOP core of the puzzle: the Entity class represents every character
(Doctor, Soldier, Child, Dog) with attributes that drive the puzzle rules
instead of hard-coded names -- this keeps the rule-checking generic and
easy to extend with new characters later.
"""

import pygame
from utils import load_image


class Entity:
    """A single character/object that can be placed on a bank or on the raft."""

    def __init__(self, name, color, image_path, can_row=False,
                 is_supervisor=False, is_volatile=False):
        self.name = name
        self.color = color
        self.can_row = can_row          # Can this entity pilot the raft?
        self.is_supervisor = is_supervisor  # Calms volatile entities nearby
        self.is_volatile = is_volatile      # Becomes dangerous if unsupervised
        self.image = load_image(image_path, (60, 60), color)
        self.rect = self.image.get_rect(center=(0, 0))
        self.side = "start"             # "start", "raft", or "end"
        self.selected = False

    def set_pos(self, pos):
        self.rect.center = pos

    def draw(self, surface, font):
        surface.blit(self.image, self.rect)
        label = font.render(self.name, True, (255, 255, 255))
        surface.blit(label, (self.rect.centerx - label.get_width() // 2,
                             self.rect.bottom + 2))
        if self.selected:
            pygame.draw.rect(surface, (255, 255, 0), self.rect, 3)


ENTITY_DEFS = {
    "Doctor": dict(
        color=(70, 130, 180),
        image_path="assets/images/doctor.png",   # <-- IMAGE: Doctor sprite
        can_row=True, is_supervisor=True, is_volatile=False,
    ),
    "Soldier": dict(
        color=(90, 90, 90),
        image_path="assets/images/soldier.png",  # <-- IMAGE: Soldier sprite
        can_row=True, is_supervisor=False, is_volatile=False,
    ),
    "Child": dict(
        color=(255, 200, 100),
        image_path="assets/images/child.png",    # <-- IMAGE: Child sprite
        can_row=False, is_supervisor=False, is_volatile=False,
    ),
    "Dog": dict(
        color=(160, 100, 60),
        image_path="assets/images/dog.png",      # <-- IMAGE: Dog sprite
        can_row=False, is_supervisor=False, is_volatile=True,
    ),
    "Tiger": dict(
        color=(230, 140, 20),
        image_path="assets/images/tiger.png",    # <-- IMAGE: Tiger sprite (Level 2 only)
        can_row=False, is_supervisor=False, is_volatile=True,
    ),
}


def create_entities(keys=None):
    """Build the Entity objects for a level. `keys` controls the roster --
    e.g. Level 1 uses the base 4, Level 2 adds 'Tiger' too."""
    if keys is None:
        keys = ["Doctor", "Soldier", "Child", "Dog"]
    return {name: Entity(name, **ENTITY_DEFS[name]) for name in keys}


def bank_is_dangerous(bank_entities):
    """
    Puzzle rule (the core 'win/lose condition' logic required by the brief):

    The Dog (a *volatile* entity) becomes dangerous when left alone with the
    Soldier or the Child -- in the story, the Soldier's weapon spooks the Dog,
    or the Dog gets overprotective of the Child -- and BOTH situations draw
    the attention of the zombie horde UNLESS the Doctor (the *supervisor*)
    is also present to keep things calm.

    This is written generically using entity attributes (is_volatile /
    is_supervisor) rather than hard-coded names, so new entities/rules can
    be added later without touching this function.
    """
    volatile_present = any(e.is_volatile for e in bank_entities)
    supervisor_present = any(e.is_supervisor for e in bank_entities)
    others_present = any(
        (not e.is_volatile) and (not e.is_supervisor) for e in bank_entities
    )
    return volatile_present and others_present and not supervisor_present
