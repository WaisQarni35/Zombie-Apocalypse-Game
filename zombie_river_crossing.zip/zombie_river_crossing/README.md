# Zombie Apocalypse: River Crossing

A 2D OOP puzzle game built with Python + Pygame for SWC3643 (River Crossing
Puzzle Adventure project brief).

## Story / Theme
A Doctor, a Soldier, a Child, and a Dog must cross a river to escape a
zombie horde before it overruns the camp. The raft can only carry 2 at a
time, and only the **Doctor** or the **Soldier** can row. The **Dog**
cannot be left alone with the Soldier or the Child — without the Doctor
there to keep things calm, the situation draws zombie attention and you
lose.

## How to Run
```bash
pip install pygame
python main.py
```

## Controls (Mouse-first)
| Action                                              | How                                    |
|------------------------------------------------------|-----------------------------------------|
| Select an entity on a bank                            | Click it (yellow outline = selected)    |
| Board the selected entity onto the raft                | Click the raft                          |
| Launch the raft across the river                       | `SPACE`                                 |
| Make an entity depart the (docked) raft                | Click it while nothing is selected      |
| Pause / Resume                                          | `P`                                     |
| Restart current level                                   | `R`                                     |
| Toggle English / Bahasa Melayu                          | `L`                                     |
| Back to menu / quit                                     | `ESC`                                   |
| Start game (menu) / Next level (after winning)          | `ENTER`                                 |
| Instructions (menu)                                      | `I`                                     |

## Levels
- **Level 1 — Outskirts Camp**: Doctor, Soldier, Child, Dog. Raft capacity 2.
- **Level 2 — Last Bridge**: adds a **Tiger** (same rule as the Dog — it's
  dangerous when left with the Soldier or Child unless the Doctor is also
  present). Raft capacity is **3** on this level — with two volatile
  animals, a 2-seat raft makes the puzzle mathematically unsolvable (the
  Doctor can never leave one animal to fetch the other without it being
  left unsupervised). 3 seats let the Doctor ferry both animals together.
  Timer is also shorter (140s vs 200s).

  **Level 2 solution** (3 trips): Doctor + Dog + Tiger cross → Doctor
  returns alone → Doctor + Soldier + Child cross. Done.

## Project Structure & OOP Design
```
main.py            # Entry point, game loop
game_manager.py     # GameManager class: states, scoring, drawing, input
entities.py         # Entity class (Doctor/Soldier/Child/Dog/Tiger) + danger rule
raft.py             # Raft class: capacity, rowing rule, smooth movement
level.py            # Level class + the 2 built-in levels (level-specific roster)
utils.py            # Asset loading helpers (safe fallbacks)
settings.py         # Constants + bilingual text dictionary
assets/images/      # Put your .png artwork here
assets/sounds/      # Put your .wav / .mp3 sound here
```

## Bonus Features Implemented
- Multiple levels with increasing difficulty (Tiger added, shorter timer on Level 2)
- Scoring system (time remaining + trip efficiency)
- Menu screen with Start / Instructions / Exit
- Bilingual interface (English / Bahasa Melayu, press `L`)

## Assets To Insert
The game runs fine with colored placeholder boxes and no sound, but for
full marks drop these files into the folders below (see in-code comments
marked `<-- IMAGE:` / `<-- SOUND:` for exact lines):

**assets/images/** (background images are used directly — no rectangles
are drawn over them, so your art shows the river and banks)
- `doctor.png`, `soldier.png`, `child.png`, `dog.png`, `tiger.png` (60x60 recommended)
- `raft.png` (raft width scales with level capacity, height 70)
- `zombie.png` (70x90 recommended)
- `menu_bg.png`, `level1_bg.png`, `level2_bg.png` (1100x650 recommended — should
  depict the river + both banks, since this image IS the background)

**assets/sounds/**
- `click.wav`, `launch.wav`, `win.wav`, `lose.wav` (short sound effects)
- `menu_music.mp3` (loops on the menu screen)
- `game_music.mp3` (loops during gameplay, any level)

## Deliverables Reminder (per project brief)
- Upload this folder (with your inserted assets) to GitHub, link it in your report
- Record a gameplay demo video, upload to YouTube, link it in your report
- Write the 5-page Reflection Report (challenges, OOP design, asset
  management, puzzle rule design, future improvements)
