"""
level.py
Level class + factory for the game's levels (bonus challenge: multiple
levels with increasing difficulty).
"""


class Level:
    def __init__(self, number, name, time_limit, raft_capacity,
                 river_left, river_right, background_path, entity_keys=None):
        self.number = number
        self.name = name
        self.time_limit = time_limit
        self.raft_capacity = raft_capacity
        self.river_left = river_left
        self.river_right = river_right
        self.background_path = background_path
        # Which entities appear in this level (controls the roster built
        # by entities.create_entities). Defaults to the base 4.
        self.entity_keys = entity_keys or ["Doctor", "Soldier", "Child", "Dog"]


def get_levels():
    return [
        Level(
            number=1, name="Outskirts Camp",
            time_limit=200, raft_capacity=2,
            river_left=420, river_right=720,
            background_path="assets/images/level1_bg.png",  # <-- IMAGE: Level 1 background
            entity_keys=["Doctor", "Soldier", "Child", "Dog"],
        ),
        Level(
            # NOTE: raft_capacity is 3 here (not 2). With TWO volatile
            # entities (Dog + Tiger) both needing the Doctor's supervision,
            # a 2-seat raft creates an unsolvable deadlock -- whenever the
            # Doctor drops one animal off and goes back for the other, the
            # one he just dropped off becomes unsupervised again. A 3-seat
            # raft lets the Doctor ferry both animals together in one trip,
            # which keeps the puzzle solvable.
            number=2, name="Last Bridge (Harder)",
            time_limit=140, raft_capacity=3,
            river_left=420, river_right=720,
            background_path="assets/images/level2_bg.png",  # <-- IMAGE: Level 2 background
            entity_keys=["Doctor", "Soldier", "Child", "Dog", "Tiger"],
        ),
    ]
